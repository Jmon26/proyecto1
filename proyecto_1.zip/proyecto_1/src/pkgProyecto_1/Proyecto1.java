package pkgProyecto_1;

public class Proyecto1
{
    public static void main(String[] args)
    {
        int numero1 = 4;
        long numero2 = 983290;
        double numero3 = 2.0;
        float numero4 = 5.74f;
        boolean verdadero = true;
        char caracter1 = 'a';
        String cadena1 = "Hola Mundo";

        System.out.println("¡HOLA MUNDO!");
        System.out.println("int "+numero1+ " /long " +numero2+ " /double "+numero3+ " /float "+numero4);
        System.out.println("boolean "+verdadero+ " /char " +caracter1+ " /String " +cadena1);





    }
}
